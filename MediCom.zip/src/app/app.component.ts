import { Input } from '@angular/core';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  
  title = 'mediCom';
  BACK_ENABLED: boolean = true;

  showChat: boolean = false;
  messages = [];
  dashboardColMed: { header: string; field: string; filterMatchMode: string; type: string; colWidthPercentage: string; }[];
  dashboardDataMed: any[];
  showSelectPop: boolean = false;
  tdDeatilsDataLength: number = 10;
  noOfRows: any = [20, 30, 50, 75, 100];
  typeSearch: string;
  dashboardData: any;
  rowsPerPage: any = 20;

    constructor() {}

    ngOnInit() {
      // this.sendMessage()
      // this.colorBackRight ? this.colorBackRight : '#007bff';
      // this.colorFontRight ? this.colorFontRight : '#ffffff';
      // this.colorBackLeft ? this.colorBackLeft : '#f8f9fa';
      // this.colorFontLeft ? this.colorFontLeft : '#343a40';
      this.dashboardColMed = [
        { header: 'Medicine Name', field: 'Name', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '160px'},
        { header: 'Purpose', field: 'Purpose', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '140px'},
        { header: 'Price', field: 'Price', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '180px'},
        { header: 'Quantity', field: 'PharmacyId', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '180px'}
      ];
      this.dashboardDataMed = [
        {
           "Name":"Lipitor",
           "Purpose":"Cholestrol lowering drug",             
           "Availabity":"Yes",
           "PrescriptionNeed":"Yes",
           "Dosage":"20mg",
           "Price": "Rs.50",
           "PharmacyId":"2"
        },
        {
           "Name":"Plavix",
           "Purpose":"To prevent Thrombosis",
           "Availabity":"Yes",
           "PrescriptionNeed":"Yes",
           "Dosage":"20mg",
           "Price": "Rs.50",
           "PharmacyId":"4"
        },
        {
           "Name":"Nexium",
           "Purpose":"Reduce gastric acid",
           "Availabity":"Yes",
           "PrescriptionNeed":"Yes",
           "Dosage":"20mg",
           "Price": "Rs.50",
           "PharmacyId":"3"
        },
        {
           "Name":"Zyprexa",
           "Purpose":"TO treat Bipolar Disorder",
           "Availabity":"Yes",
           "PrescriptionNeed":"Yes",
           "Dosage":"20mg",
           "Price": "Rs.50",
           "PharmacyId":"3"
        },
        {
           "Name":"Singulair",
           "Purpose":"Treatment of Asthma",
           "Availabity":"Yes",
           "PrescriptionNeed":"Yes",
           "Dosage":"20mg",
           "Price": "Rs.50",
           "PharmacyId":"4"
        },
        {
           "Name":"Aranesp",
           "Purpose":"Cancer Chemotherapy",
           "Availabity":"Yes",
           "PrescriptionNeed":"No",
           "Dosage":"20mg",
           "Price": "Rs.50",
           "PharmacyId":"8"
        }
     ];
    }

    showChatMe (val) {
      if(val == 'true') {
        this.showChat = true;
      } else {
        this.showChat = false;
      }
      
    }
    
    cartDetails() {
      this.showSelectPop = true;
    }

}
