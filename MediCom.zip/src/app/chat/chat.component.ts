import { Component, Input } from '@angular/core';
// import { ChatService } from '../../services/chat/chat.service';

@Component({
  selector: 'chat',
    templateUrl: './chat.component.html',
    styleUrls: ['./chat.component.css']
})
export class ChatComponent {

  BACK_ENABLED: boolean = true;

  @Input('messages') messages: any[];
  @Input('colorBackRight') colorBackRight : string;
  @Input('colorFontRight') colorFontRight: string;
  @Input('colorBackLeft') colorBackLeft: string;
  @Input('colorFontLeft') colorFontLeft: string;

  textInput: string = '';
  jsonData:{request:string,response:string}[];

  constructor() {}

  ngOnInit() {
    // this.colorBackRight ? this.colorBackRight : '#007bff';
    // this.colorFontRight ? this.colorFontRight : '#ffffff';
    // this.colorBackLeft ? this.colorBackLeft : '#f8f9fa';
    // this.colorFontLeft ? this.colorFontLeft : '#343a40';
this.jsonData=[{"request":"Hi","response":"Hi! I'm Medicom and I'm a Chatbot. I can help you with pharma related topics. What would you like to know!"},
{"request":"List of Pharmacy near me","response":"1.SunFarm Pharmacy,Chennai 2.Alon Pharmacy,Chennai 3.Mediline Pharmacy,Chennai"},
{"request":"I need list of tablets available in Alon Pharmacy","response":"1.Isoflurane 2.Propofol 3.Sevoflurane 4.Diazepam 5.Midazolam 6.Tramadol"},
{"request":"Is Propofol available in Alon Pharmacy?","response":"Cholestrol lowering drug"},
{"request":"Location of Alon Pharmacy","response":"No 345, Srivenkateshwara street, Anna Nagar, Chennai"},
{"request":"Contact number of Alon Pharmacy","response":"Contact number : 8794223252, Mail ID : alonphrama@hotmail.com"},
{"request":"At what time Alon Pharmacy will open?","response":"Opening time is 10.00 AM"},
{"request":"At what time Alon Pharmacy will close?","response":"Opening time is 09.00 PM"},
{"request":"Which pharmacy have 100mg Isoflurane","response":"1.SunFarm Pharmacy,Chenai"},
{"request":"ALON","response":"Code : ALON, Name : Alon Pharmacy, Address: No 767,Eshwari nagar,Chennai. Contact number : 7989565666 Mail Id: alonpharma@hotmail.com"},
{"request":"Alon Pharmacy","response":"Code : ALON, Name : Alon Pharmacy, Address: No 767,Eshwari nagar,Chennai. Contact number : 7989565666 Mail Id: alonpharma@hotmail.com"},
{"request":"Pharmacy above 4.5 rating in Chennai","response":"1.SunFarm Pharmacy,Chennai 2.Mediline Pharmacy,Chennai"},
{"request":"Pharmacy above 3.5 rating in Anna Nagar","response":"1.Alon Pharmacy,Chennai"},
{"request":"Pharmacy above 4.5 rating in Chennai","response":"1.SunFarm Pharmacy,Chennai 2.Mediline Pharmacy,Chennai"},
{"request":"Cost of Propofol","response":"Sorry, I can't disclose this information. Please contact Alon Pharmacy for further details."},
{"request":"hfajdhflaidf","response":"Sorry, I couldn't understand. Kindly rephrase your sentence."},
{"request":"Pai","response":"Sorry, It looks like we don't have any related pharma details at this."},
{"request":"Thank you","response":"Is there any other issue I can help?"},
{"request":"No","response":"Thank you for contacting us. Have a great day. "}
];

  }

  sendMessage() {
    let newMessage = {"text": this.textInput, "date":"", "userOwner":true};
    this.messages.push(newMessage);
    let messageBack = {"firstname": "Simon", "text": this.textInput};
    if (this.BACK_ENABLED) {
        // this.chatService.sendMessage(messageBack).then(
        //     (res) => {
        //         let messageReturn = {"text": res.json().speech_answer, "date": "", "userOwner": false};
        //         this.messages.push(messageReturn);
        //     });
        let filterData=this.jsonData.filter(x=>x.request.includes(this.textInput))[0];
console.log(filterData)
        if(filterData)
        {
          let messageReturn = {"text": filterData.response, "date": "09/09/2020", "userOwner": false};
        this.messages.push(messageReturn);
        }
        else{
          let messageReturn = {"text": "I can't understand", "date": "09/09/2020", "userOwner": false};
          this.messages.push(messageReturn);
        }
    }
    this.textInput = '';
  }

  onKey(event: any) {
    console.log(this.textInput)
    if (event.keyCode == 13) {
      this.textInput=this.textInput.trim();
      console.log(this.textInput.trim())
      this.sendMessage();
      console.log(this.textInput)
      event.preventDefault();
    }
  }

}
