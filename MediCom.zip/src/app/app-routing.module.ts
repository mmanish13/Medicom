import { NgModule, OnInit, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent   
  },
  {
    path: 'register',
    component: RegisterComponent    
  },
  {
    path: '',
    component: LoginComponent   
  },
  {
    path: 'dashboard',
    component: DashboardComponent   
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule implements OnInit {
  constructor () {}
  ngOnInit (){

  }
 }
