import { Component, OnInit } from '@angular/core';
import { Dropdown } from 'primeng/dropdown';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  tdDeatilsDataLength: number = 10;
  noOfRows: any = [20, 30, 50, 75, 100];
  typeSearch: string;
  dashboardData: any;
  rowsPerPage: any = 20;
  dashboardCol: any;
  Description: string = 'Pharmacy';
  dashboardDataPharma: any[];
  dashboardDataMedi: any[]; 

  SearchVal: any = "pharmacy";
  dashboardColPh: { header: string; field: string; filterMatchMode: string; type: string; colWidthPercentage: string; }[];
  dashboardColMed: { header: string; field: string; filterMatchMode: string; type: string; colWidthPercentage: string; }[];
  dashboardDataPh: any[];
  dashboardDataMed: any[];
  showPh: boolean = true;
  showMed: boolean;
  showSelectPop: boolean = false;
  pharmaAvailableMed: any[];
  nameSearch: any;
  
  constructor() { }

  ngOnInit(): void {
    this.searchChange("pharmacy");
    this.SearchVal = [
      {label: 'Pharmacy', value: 'pharmacy'},
      {label: 'Medicine', value: 'medicine'},
      {label: 'Hospital', value: 'hospital'}
    ]; 

    this.dashboardColPh = [
      { header: 'ID', field: 'Id', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '100px'},
      { header: 'Pharmacy Code ID', field: 'Code', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '200px'},
      { header: 'Pharmacy Name', field: 'Name', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '180px'},
      { header: 'Address', field: 'Address', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '450px'},
      { header: 'Contact Details', field: 'Contact', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '160px'},
      { header: 'Web Link', field: 'Website', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '250px'},
      { header: 'Pharmacy Status', field: 'Status', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '160px'},
      { header: 'Pharmacy Rating', field: 'Rating', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '180px'},
      { header: 'Pharmacy Distance', field: 'Distance', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '220px'}
    ];
    this.dashboardColMed = [
      { header: 'Medicine Name', field: 'Name', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '160px'},
      { header: 'Purpose', field: 'Purpose', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '140px'},
      { header: 'Category', field: 'Category', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '240px'},
      { header: 'Availability', field: 'Availabity', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '180px'},
      { header: 'Prescription Req', field: 'PrescriptionNeed', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '160px'},
      { header: 'Dosage', field: 'Dosage', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '140px'},
      { header: 'Price', field: 'Price', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '180px'},
      { header: 'Pharmacy ID', field: 'PharmacyId', filterMatchMode: 'contains', type: 'text', colWidthPercentage: '180px'}
    ];
    this.dashboardDataPh = [
      {
         "Id":"1",
         "Code":"ARIES",
         "Name":"ARIES",
         "Address":"346 pantheon road , egmore",
         "Contact":"4428193404",
         "Website":"www.aries.com",
         "Status":"Open",
         "Rating":"4.2",
         "Distance":"1 Km"
      },
      {
        "Id":"2",
         "Code":"PTN",
         "Name":"Periodic Table Now",
         "Address":"346 pantheon road , egmore",
         "Contact":"7748805122",
         "Website":"www.periodictablenow.com",
         "Status":"Open",
         "Rating":"3.6",
         "Distance":"1.5 Km"
      },
      {
        "Id":"3",
         "Code":"CONPHAR",
         "Name":"Concern pharma",
         "Address":"699/700 P.H Road, 14, 2nd floor kumbath complex, Chennai",
         "Contact":"4426641900",
         "Website":"Www.concernpharma.com",
         "Status":"Open",
         "Rating":"3.5",
         "Distance":"2 Km"
      },
      {
        "Id":"4",
         "Code":"SAN",
         "Name":"SANeFORCE",
         "Address":"Chennai",
         "Contact":"9841316719",
         "Website":"www.SANeFORCE.com",
         "Status":"Closed",
         "Rating":"4.5",
         "Distance":"3 Km"
      },
      {
        "Id":"5",
         "Code":"MLYTE",
         "Name":"Microlyte",
         "Address":"No.31,palandi amman koil street,adambakkam chennai-600088",
         "Contact":"4464585960",
         "Website":"www.microlyte.com",
         "Status":"Closed",
         "Rating":"2.2",
         "Distance":"5 Km"
      },
      {
        "Id":"6",
         "Code":"NILPTD",
         "Name":"NANDHINI INSULATIONS AND LININGS PRIVATE LIMITED",
         "Address":"63 BALAJI NAGAR MEHTA AVENUE PADIKUPPAM ROAD ANNA NAGAR WEST CHENNAI",
         "Contact":"26156663",
         "Website":"www.nilptd.com",
         "Status":"Closed",
         "Rating":"4.8",
         "Distance":"7 Km"
      },
      {
        "Id":"7",
         "Code":"AXON",
         "Name":"Axon Drugs Pvt Ltd",
         "Address":"K- 95, 16th Street, K - Block, Annanagar East,",
         "Contact":"(44) 42171424",
         "Website":"www.axon.com",
         "Status":"Open",
         "Rating":"4.5",
         "Distance":"10 Km"
      },
      {
        "Id":"8",
         "Code":"ASTONS",
         "Name":"Astons Pharmacia Pvt Ltd",
         "Address":"No.2, S. R. P. Koil Street, 2nd Floor, Thiru-Vi-KA-Nagar, Perambur",
         "Contact":"7828193404",
         "Website":"www.astons.com",
         "Status":"Open",
         "Rating":"1.8",
         "Distance":"12 Km"
      },
      {
        "Id":"9",
         "Code":"AKAS",
         "Name":"Akas Medical Eqipment",
         "Address":"No.240/1, Periya Colony, Athipet,Ambattur",
         "Contact":"(44) 28111999",
         "Website":"www.akas.com",
         "Status":"Open",
         "Rating":"4.9",
         "Distance":"15 Km"
      },
      {
        "Id":"10",
         "Code":"AKAS",
         "Name":"Akas Medical Eqipment",
         "Address":"No.240/1, Periya Colony, Athipet,Ambattur",
         "Contact":"(44) 28111999",
         "Website":"www.akas.com",
         "Status":"Open",
         "Rating":"4.9",
         "Distance":"16 Km"
      }
   ];
   this.dashboardDataMed = [
      {
         "Name":"Lipitor",
         "Purpose":"Cholestrol lowering drug",
         "Category": "Antibiotics & Antiseptics",            
         "Availabity":"Yes",
         "PrescriptionNeed":"Yes",
         "Dosage":"20mg",
         "Price": "Rs.50",
         "PharmacyId":"1"
      },
      {
         "Name":"Plavix",
         "Purpose":"To prevent Thrombosis",
         "Category": "Cough, Cold & Flu",
         "Availabity":"Yes",
         "PrescriptionNeed":"Yes",
         "Dosage":"20mg",
         "Price": "Rs.50",
         "PharmacyId":"1"
      },
      {
         "Name":"Nexium",
         "Purpose":"Reduce gastric acid",
         "Category": "Allergy & Sinus",
         "Availabity":"Yes",
         "PrescriptionNeed":"Yes",
         "Dosage":"20mg",
         "Price": "Rs.50",
         "PharmacyId":"2"
      },
      {
         "Name":"Zyprexa",
         "Purpose":"TO treat Bipolar Disorder",
         "Category": "Diabetes",
         "Availabity":"Yes",
         "PrescriptionNeed":"Yes",
         "Dosage":"20mg",
         "Price": "Rs.50",
         "PharmacyId":"2"
      },
      {
         "Name":"Singulair",
         "Purpose":"Treatment of Asthma",
         "Category": "Sleep & Snoring Aids",
         "Availabity":"Yes",
         "PrescriptionNeed":"Yes",
         "Dosage":"20mg",
         "Price": "Rs.50",
         "PharmacyId":"3"
      },
      {
         "Name":"Aranesp",
         "Purpose":"Cancer Chemotherapy",
         "Category": "Cancer",
         "Availabity":"Yes",
         "PrescriptionNeed":"No",
         "Dosage":"20mg",
         "Price": "Rs.50",
         "PharmacyId":"5"
      }
   ];
  }

  rowClick(val, rowData) {
   this.showSelectPop = true;
   this.pharmaAvailableMed=this.dashboardDataMed.filter(x=>x.PharmacyId == rowData.Id);
  }

  searchChange(val) {
    if(val == "pharmacy"){
      this.showPh = true;
      this.showMed = false;
      this.dashboardDataPharma = this.dashboardDataPh;
    }else if(val == "medicine"){
      this.showMed = true;
      this.showPh = false;
      this.dashboardDataMedi = this.dashboardDataMed;
    }
  } 

  

  searchNameChange(val)

  {
    this.nameSearch = val;
      if(this.showPh === true)
      {
        if(this.nameSearch === "")
        {
          this.dashboardDataPharma = this.dashboardDataPh;
        }
        this.dashboardDataPharma = this.dashboardDataPh.filter(x => x.Name.toLowerCase().includes(this.nameSearch.toLowerCase()));
        }

      if(this.showMed === true)
      {
        if(this.nameSearch === "")
        {
          this.dashboardDataMedi = this.dashboardDataMed;
        }
        this.dashboardDataMedi = [];
        this.dashboardDataMedi = this.dashboardDataMed.filter(x => x.Name.toLowerCase().includes(this.nameSearch.toLowerCase()));
      }
    }

    onChangeEvent(event,data) {
      console.log(event)
      console.log(data)
     if( event.value>data.PharmacyId)
     {
       this.dashboardDataMed.filter(x=>x.PharmacyId==data.PharmacyId)[0].AddCard=data.PharmacyId;
         return true;
     }
   }

}
