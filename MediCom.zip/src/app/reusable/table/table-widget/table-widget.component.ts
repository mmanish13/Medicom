import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef, ViewChild, ElementRef, TemplateRef } from '@angular/core';
import { MenuItem, LazyLoadEvent, SelectItem, ConfirmationService } from 'primeng/components/common/api';
import { Observable, Subject, BehaviorSubject, throwError as _observableThrow, of as _observableOf, Subscription } from 'rxjs';
//import { DropdownValuesService } from '../service/dropdown-values.service';
import * as DateFns from 'date-fns';
import * as Enumerable from 'linq';
import { DatePipe } from '@angular/common';
import { Table } from 'primeng/table';
import { Constants } from 'src/app/constants';
import { GpArithmosServices } from '../../model/gp-arithmos-services.service';
import { TargetLazyLoad } from '../../model/Target/target-lazy-load';
import { Validators, FormBuilder, FormControl } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonLazyLoad } from '../../model/Common/common-lazy-load';
import { Event } from '@angular/router';
import { GpChildServiceService } from '../../model/gp-internal-service.service';
// declare var $: any;
export class ColumnDef {
  public constructor(init?: Partial<ColumnDef>) {
    Object.assign(this, init);
  }

  public header: string;
  public field: string;
  public type?= 'text';
  public textHighlight?:boolean = false;
  public sortShow?: boolean = true;
  public colWidthPercentage?: string;
  public filterMatchMode?= 'contains';
  public codeList?: string = null;
  public visible?= true;
  public sortType?: any;
  public isEditable?= false;
  public align?: string = 'left';
  public dropDownValName?: string = null;
  public curFormat?: any = [];
  public noOfChar?: number = 50;
  public defaultsForFilter?: (items: SelectItem[]) => SelectItem[] = e => e;
}

@Component({
  selector: 'app-table-widget',
  templateUrl: './table-widget.component.html',
  styleUrls: ['./table-widget.component.scss']
})
export class TableWidgetComponent<T> implements OnInit {
  public _Cols: ColumnDef[];
  public originalGridData: any[];
  public gridData: T[] = [];
  @ViewChild('grid') public GridRef: Table;
  @ViewChild('gridWidgetDiv') public gridWidgetDiv: ElementRef;
  @Output() public gridDataChange: EventEmitter<T[]> = new EventEmitter();
  @Input() public totalRecords: number=0;
  numberDecCheck: any;
  showTdDetails: boolean;
  tdColumns: { field: string; header: string; }[];
  //tdDeatilsData: { blendLevel: string; blendedNDC1: string; blendedNDC2: string; twoWayBlend: string; effectiveDate: string; expDate: string; }[];
  tdDeatilsDataLength: number;
  tdDeatilsDataHeader: any;
  dateFilters: any;
  tdDeatilsData: any[];
  previousFilteredVal: T[];
  tableHeaderCheckboxSelectedAll: boolean = false;
  @Input() public set Cols(value: ColumnDef[]) {
    if (value) {
      this.DefaultColumns = value.map(e => new ColumnDef(e));
      this._Cols = value.map(e => new ColumnDef(e));
      this.selectedColumns = this._Cols.map(e => new ColumnDef(e));
    }
  }
  @Input() public set GridData(value: T[]) {
    if (value) {
      this.totalRecords = this.totalRecords > 0 ? this.totalRecords : value.length;
      let scrollableCnt = document.getElementsByClassName('ui-table-scrollable-body');
      for(var i=0; i<scrollableCnt.length;i++){
        scrollableCnt[i].scrollBy(100, 0);
        scrollableCnt[i].scrollLeft=0;
      }
      if(this.HasCheckBoxMultiSelect)
      this.tableHeaderCheckboxSelectedAll = false;
      this.originalGridData = value;
      this.gridData = value;
      
      // this.GridRef.reset();
      this.filterSelectItems.clear();
      this.GridRef.reset();
      this.selectedRowsData = [];
      this.LoadVirtualRecords(value);
      if(this.gridData.length >= 1 && this.selectAllCheckbox) {
        this.onHeaderCheckboxToggle(true);
        this.tableHeaderCheckboxSelectedAll = true;
      }
    }
  }
  @Input() public additionalHeader ?: boolean = false;
  @Input() public additionalHeaderContent ?= [];
  @Input() public dropdownData = null;
  @Input() public Description = 'Records';
  @Input() public dataKey = 'id';
  @Input() public Name = '';
  @Input() public isLoading: boolean;
  @Input() public scrollHeight = '250px';
  @Input() public rowsPerPage = 100;
  @Input() public disableHeaderCheckbox ?: boolean = false;
  @Input() public disableChildCheckbox ?: boolean = false;
  @Input() public selectAllCheckbox ?: boolean = false;
  @Input() public noOfRows = [20, 30, 50, 75, 100];
  @Input() public isPaginator = true;
  @Input() public RightClickHandler: (rowData: T, menuItems: MenuItem[]) => void;
  @Input() public HasFilters: boolean; // Flag to say if table has a header row with filter
  @Input() public HasCheckBoxMultiSelect: boolean;
  @Input() public selectedRowsData: any[];
  @Input() public isLazyLoad = false;
  @Input() public loading = false;
  // Used to Customize the <td> output if necessary! e.g. when you want RED text based on some conditions
  @Input() tdTemplate: TemplateRef<any>;
  // Used to Customize the <th> header row for column wise filters if necessary!
  @Input() filterTemplate: TemplateRef<any>;
  @Input() addHeaderTemplate: TemplateRef<any>;
  @Input() public captionVal = '';
  @Input() public isCaption = false;
  @Input() public filterDropdownData = null;
  public targetLazyLoad: any;


  @Output() public selectedRowsDataChange: EventEmitter<T[]> = new EventEmitter();
  @Output() RowsSelectionChange: EventEmitter<T[]> = new EventEmitter(); // Event when rows selected using checkBox
  @Output() RowLeftClick: EventEmitter<T> = new EventEmitter(); // Event when a row is selected using left click
  @Output() onLazyLoadEvent: EventEmitter<T> = new EventEmitter(); // Event when a lazyload enabled
  @Output() DropdownChangeEvent: EventEmitter<T> = new EventEmitter(); // Event when a dropdown change 
  @Output() KeyPressEvent: EventEmitter<T> = new EventEmitter(); // Event when a textbox keypress 
  @Output() LinkIconClickEvent: EventEmitter<T> = new EventEmitter(); // Event when a linkIcon is clicked  
  @Output() showTdDetailsEvent: EventEmitter<T> = new EventEmitter();
  /*Event when a textbox has key up. Difference between keypress and keyup is, keypress don't fire during backspace, but keyup does. Kedown also fires at backspace, but
  in keyup the model of the grid updates, but in keydown the model don't update*/
  @Output() KeyUpEvent: EventEmitter<T> = new EventEmitter();
  @Output() KeyDownEvent: EventEmitter<T> = new EventEmitter();
  
  public interalContextHeaderMenuItems: MenuItem[] = [];
  protected _rightClickSelectedColData: ColumnDef;
  public selectedColumns: ColumnDef[] = [];
  public DefaultColumns: ColumnDef[] = [];
  protected prevTargetRowData: T = null; // used to clear the formatting
  protected prevTarget = null; // used to clear the formatting
  public ColumnSelectAllFlag: boolean;
  public showColumnHeaderFlag = false;
  protected filterSelectItems: Map<string, SelectItem[]> = new Map();
  private dateA: Date;
  private dateB: Date;
  private numberCheck: any;
  private lazyCount: number =0;
  private subscriptionLazyLoad: Subscription;


  constructor(protected cdr: ChangeDetectorRef, private spinner: NgxSpinnerService, private formBuilder: FormBuilder, private service: GpArithmosServices, private inetrnalService: GpChildServiceService) {
    // this.service.gridLazyDataLoad.subscribe((lazyValue:any) => {
    //   console.log("Lay1",lazyValue);
    //  if(lazyValue!=null){
    //   this.gridData = lazyValue.result;
    //   this.totalRecords = lazyValue.totalCount;
    //  }
    // });
    
  }

  ngOnInit() {
    if (this._Cols) {
      this.selectedColumns = this._Cols.map(e => new ColumnDef(e));
    }
    // this.GridRef.filterConstraints['dateRangeFilter'] = (value, filter): boolean => {
    //   var s = this.dateFilters[0].getTime();
    //   var e;
    //   if (this.dateFilters[1]) {
    //     e = this.dateFilters[1].getTime() + 86400000;
    //   } else {
    //     e = s + 86400000;
    //   }
    //   value = new Date(value);
    //   return value.getTime() >= s && value.getTime() <= e;
    // }
    // this.GridRef.filterConstraints.contains = (value, filter: any): boolean => {
    //     if (filter === undefined || filter === null || filter === '') {
    //       return true;
    //     }
    //     if (value === undefined || value === null) {
    //       return false;
    //     }
    //     if(typeof(value) == "number"){
    //       value = value.toString();
    //     }
    //     if(filter && value.includes(filter)){
    //       return true;
    //     }
    //   };
    }

    checkboxCheck(evet) {
      if(this.HasCheckBoxMultiSelect){
        if(evet.key == "Delete" || evet.key == "Backspace" || evet.key == " "){
          if(Object.keys(this.GridRef.filters).length == 0){
            this.tableHeaderCheckboxSelectedAll = false;
          }else if(Object.keys(this.GridRef.filters).length > 0 && this.GridRef.filteredValue !== null) {
            var chekcedRowsVal = this.GridRef.filteredValue.filter(x=> x.checked == false);
            if(chekcedRowsVal.length > 0)
            this.tableHeaderCheckboxSelectedAll = false;
          }
        }
      }
    }
  getDropDownValues(dropVal) {
    //return dropVal[0];
  }
  getColSpanEmptyMessage() {
    if (this._Cols)
      return this._Cols.filter(c => c.visible).length + (this.HasCheckBoxMultiSelect ? 1 : 0);
  }
  public getValueAsString(rowItem, col): string {
    const val = rowItem[col.field];
    if (val != null && val != "") {
      switch (col.type) {
        case 'date': return DateFns.format(val, 'MM/DD/YYYY');
        case 'datetime': return DateFns.format(val, 'DD-MMM-YYYY HH:mm:ss');
        case 'dateQuarter': return DateFns.format(val, 'MM/DD/YYYY'); // Code added by pxt73120
        case 'bool': return val ? 'Yes' : 'No';
        case 'dropdown': return val.value;
        default:
          {
            return val;
          }
      }
    }
    return null;
  }

  decimalcheck(event, data, index, field){
    var val = event.srcElement.value;
    if(isNaN(val)){
      val = val.replace(/[^0-9\.]/g,'');
      if(val.split('.').length>2) 
          val =val.replace(/\.+$/,"");
          data[field] = val;
    }

    this.textBoxKeyUpEvent(event, index, data,field);
  }
  onselectDatePicker(date: Date, index, filed) {
    this.gridData[index][filed] = DateFns.format(date, 'DD-MMM-YYYY');
    this.gridDataChange.emit(this.gridData);
  }

  onHeaderRightClick($event, rightClickSelectedItem: ColumnDef, hcm) {
    this._rightClickSelectedColData = rightClickSelectedItem;
    $event.rightClickSelectedItem = rightClickSelectedItem;

    this.interalContextHeaderMenuItems = [
      {
        label: rightClickSelectedItem ? 'Hide \'' + this._rightClickSelectedColData.header + '\'' : 'Hide',
        icon: 'pi pi-minus-circle',
        disabled: rightClickSelectedItem ? false : true,
        command: (event) => { this.hideSpecficColumn(); }
      },
      {
        label: 'Select Columns',
        icon: 'pi pi-check-circle',
        command: (event) => {
          this.showColumnHeaderFlag = true;
          this.onColumnSelectChange();
        }
      },
      {
        label: 'Reset To Defaults',
        icon: 'pi pi-refresh',
        command: (event) => { this.restoreDefault(); }
      }
    ];

    hcm.show($event);
  }

  hideSpecficColumn() {
    this._rightClickSelectedColData.visible = false;

    this.selectedColumns = this._Cols.map(e => new ColumnDef(e));
    this.cdr.detectChanges();
  }

  restoreDefault() {
    this._Cols = this.DefaultColumns.map(e => new ColumnDef(e));
    this.selectedColumns = this._Cols.map(e => new ColumnDef(e));
    this.cdr.detectChanges();
  }

  mySort(event: any, field: string) {
    //console.log(event, field);
  }

  saveChanges() {
    //console.log('working..');
  }

  customSort(event) {
    this.spinner.show(Constants.Spinner);
    let value = event.data[0][event.field];

    var check = this._Cols.filter(e => e.field === event.field)[0].type;
    let eventField = typeof (value);
    if (eventField !== 'number' && value !== null) {
      let valueSplit = value.split("/");
      if (valueSplit.length === 3) {
        if(valueSplit[0].length == 2 && valueSplit[1].length == 2 && valueSplit[2].length == 4){
          eventField = 'object';
        }
      }
    } else if(eventField !== 'number' && value === null) {
      eventField = 'object';
    }
    this.numberCheck = new FormControl(value, Validators.pattern(/^-?\d+$/));
    this.numberDecCheck = new FormControl(value, Validators.pattern(/^(?:[0-9]+(?:\.[0-9]{0,2})?)?$/));
    if ((this.numberCheck.status === "VALID" || this.numberDecCheck.status === "VALID") && check != "text" ) { 
      eventField = 'number';
    }
    if(value === ""){
      eventField = 'string';
    } else if(value === null){
      eventField = 'object';
    }
    const evnetType = this.selectedColumns.filter(x => x.field == event.field)[0];
    if((value == null || value == "") && evnetType.sortType) 
    eventField = evnetType.sortType;

    if (event.order === 1) {
      this.spinner.show(Constants.Spinner);
      event.data.sort(function (a, b) {
        if (eventField === 'number') {
          var dateA: any = parseFloat(a[event.field]),
            dateB: any = parseFloat(b[event.field]);
            if(a[event.field] == null){
              dateA = '';
            }
            if(b[event.field] == null){
              dateB = '';
            }
          return dateA - dateB;
        } else if (eventField === 'string') {
          var dateA: any = a[event.field] == null ? '' : a[event.field].toLowerCase(),
            dateB: any = b[event.field] == null ? '' : b[event.field].toLowerCase();
          return dateA > dateB ? 1 : -1;
        } else if (eventField === 'object') {
          var dateA: any = DateFns.format(new Date(a[event.field]), 'YYYY-MM-DD'),
            dateB: any = DateFns.format(new Date(b[event.field]), 'YYYY-MM-DD');
            return (dateA < dateB) ? -1 : (dateA > dateB) ? 1 : 0;
        }
      });
    } else if (event.order === -1) {
      this.spinner.show(Constants.Spinner);
      event.data.sort(function (a, b) {
        if (eventField === 'number') {
          var dateA: any = parseFloat(a[event.field]),
            dateB: any = parseFloat(b[event.field]);
            if(a[event.field] == null){
              dateA = '';
            }
            if(b[event.field] == null){
              dateB = '';
            }
          return dateB - dateA;
        } else if (eventField === 'string') {
          var dateA: any = a[event.field] == null ? '' : a[event.field].toLowerCase(),
            dateB: any = b[event.field] == null ? '' : b[event.field].toLowerCase();
          return dateA > dateB ? -1 : 1;
        } else if (eventField === 'object') {
          var dateA: any = DateFns.format(new Date(a[event.field]), 'YYYY-MM-DD'),
            dateB: any = DateFns.format(new Date(b[event.field]), 'YYYY-MM-DD');
            return (dateA < dateB) ? 1 : (dateA > dateB) ? -1 : 0;
        }
      });
    }
    this.spinner.hide(Constants.Spinner);
  }

  onColumnHeaderCheckboxToggle(checked: boolean) {
    this.selectedColumns.forEach(e => e.visible = checked);
  }
  onColumnSelectChange() {
    if (this.selectedColumns.length === this.selectedColumns.filter(e => e.visible === true).length) {
      this.ColumnSelectAllFlag = true;
    } else {
      this.ColumnSelectAllFlag = false;
    }
  }
  showFilteredColumns() {
    this.showColumnHeaderFlag = false;
    this._Cols = this.selectedColumns.map(e => new ColumnDef(e));
    this.cdr.detectChanges();
  }

  onColResize($event) {
    // this.UpdateColWidthPref();
  }

  protected selectionChangeHandler(event) {
    this.refreshHeaderCheckboxState();
    this.selectedRowsDataChange.emit(this.selectedRowsData);
    this.RowsSelectionChange.emit(this.selectedRowsData);
    if (event.originalEvent && event.originalEvent.originalEvent) {
      event.originalEvent.originalEvent.stopPropagation();
    } else if (event.originalEvent) {
      event.originalEvent.stopPropagation();
    }
  }
  onRowSelect(event,val) {
    //this.selectionChangeHandler(event,val);
    var checkVal = {'checked' : val};
    var eventDataArr = [];
    eventDataArr[0] = event.data;
    let merged = Object.assign(eventDataArr,checkVal);
    this.RowsSelectionChange.emit(merged);
  }
  onRowUnselect(event,val) {
    //this.selectionChangeHandler(event,val);
    var checkVal = {'checked' : val};
    var eventDataArr = [];
    eventDataArr[0] = event.data;
    let merged = Object.assign(eventDataArr,checkVal);
    this.RowsSelectionChange.emit(merged);
  }
  getKey(item: T) {
    return this.getDescendantProp(item, this.dataKey);
  }
  getDescendantProp(obj: any, desc: string) {
    const arr = desc.split('.');
    while (arr.length && obj) { obj = obj[arr.shift()]; }
    return obj;
  }
  rowTrackByFunction = (index: number, item: T) => {
    return this.getKey(item);
  }
  OnRowClick(event: MouseEvent, rowIndex: number, selectedRowData: T) {
    //console.log(selectedRowData);
    this.HandleRowClick(event, selectedRowData);
  }
  private HandleRowClick(event: any, selectedRowData: T) {
    if (this.prevTarget) {
      this.prevTarget.classList.remove('selectedRow');
      this.prevTargetRowData['__selected'] = false;
    }
    event.currentTarget.classList.add('selectedRow');
    selectedRowData['__selected'] = true;
    this.prevTarget = event.currentTarget;
    this.prevTargetRowData = selectedRowData;
    this.RowLeftClick.emit(selectedRowData);
  }
  cloneEvent(e: Event) {
    if (e === undefined || e === null) { return undefined; }
    const evt = {};
    for (const p in e) {
      const d = Object.getOwnPropertyDescriptor(e, p);
      if (d && (d.get || d.set)) { Object.defineProperty(evt, p, d); } else { evt[p] = e[p]; }
    }
    Object.setPrototypeOf(evt, e);
    return evt;
  }
  onHeaderCheckboxToggle(checked: boolean) {
    var merged;
    if(this.GridRef.filteredValue !== null){
      this.selectedRowsData = this.GridRef.filteredValue;
      this.previousFilteredVal = this.selectedRowsData;
    } else {
      this.selectedRowsData = Enumerable.from(this.selectedRowsData).union(this.originalGridData, e => this.getKey(e)).toArray();
    }
    
    if (checked) {
      var checkVal = {'checked' : true};
      // this.selectedRowsData = Enumerable.from(this.selectedRowsData)
      //   .union(this.originalGridData, e => this.getKey(e))
      //   .toArray();
        merged = Object.assign(this.selectedRowsData,checkVal);
    } else {
      this.selectedRowsData = [];
      var checkVal = {'checked' : false};
      merged = Object.assign(this.originalGridData,checkVal);
    }
    //this.selectionChangeHandler(this.selectedRowsData);
   
    if(checked){
      merged = Object.assign(this.selectedRowsData,checked);
      this.selectedRowsData.forEach(x=> x.checked = checked);
      this.originalGridData.filter(x => x == this.selectedRowsData).forEach(data => {
        data.checked = checked;
      });
    } else {
      merged = Object.assign(this.originalGridData,checked);
      this.originalGridData.forEach(x=> x.checked = checked);

    }
    this.RowsSelectionChange.emit(merged);
  }


  refreshHeaderCheckboxState() {
  }


  FieldFilterOptions(col: ColumnDef): SelectItem[] {
    const fieldName = col.field;
    if (!this.filterSelectItems.has(fieldName)) {
      if (col.type !== 'bool') {
        const items = Enumerable.from(this.originalGridData).select(e =>
          <SelectItem>{ label: e[fieldName], value: e[fieldName] })
          .distinct(e => e.label)
          .orderBy(e => e.label.toLocaleLowerCase()).toArray();
        this.filterSelectItems.set(fieldName, items);
      } 
      else {
        const items = Enumerable.from(this.originalGridData).select(e =>
          <SelectItem>{ label: e[fieldName] ? 'Yes' : 'No', value: e[fieldName] })
          .distinct(e => e.label)
          .orderByDescending(e => e.label).toArray();
        this.filterSelectItems.set(fieldName, items);
      }

    //   this.populateDefaultForFilter(col);

    // }
    return this.filterSelectItems.get(fieldName);
  }
}

  populateDefaultForFilter(col: ColumnDef) {

    const fieldDefaults = col.field + '_defaults';
    if (col.filterMatchMode === 'equals') {
      if (this.GridRef.hasFilter && this.GridRef.filters[col.field]) {
        this.filterSelectItems[fieldDefaults] = this.GridRef.filters[col.field].value[0];
      }
      else {
        this.filterSelectItems[fieldDefaults] = '--All--';
      }
    } else {
      if (this.GridRef.hasFilter && this.GridRef.filters[col.field]) {
        this.filterSelectItems[fieldDefaults] = this.GridRef.filters[col.field].value;
      } else {
        const items = this.filterSelectItems.get(col.field);
        const defaults = col.defaultsForFilter ? col.defaultsForFilter(items) : items;
        this.filterSelectItems[fieldDefaults] = defaults.map(e => e.value);
      }
    }

  }

  onSelectChange($event, grid, col) {
    if ($event.target.value === '--All--') {
      grid.filter('', col.field, 'equals');
    } else {

      let filteredValue = $event.target.value;
      if (col.type === 'bool') {
        if ($event.target.value === 'true') {
          filteredValue = true;
        } else {
          filteredValue = false;
        }
      }
      grid.filter([filteredValue], col.field, 'in');
    }
  }

  private LoadVirtualRecords(value: T[]) {
    let hasToFilter = false;
    const filters = {};
    if (this.HasFilters) {
      if (this.GridRef.hasFilter()) {
        hasToFilter = true;
        if (this.GridRef) {
          this.GridRef._filter();
        }
      } else {
        this._Cols.forEach(col => {
          if (col.filterMatchMode === 'in' && col.defaultsForFilter) {
            this.FieldFilterOptions(col);
            filters[col.field] = { value: this.filterSelectItems[col.field + '_defaults'], matchMode: 'in' };
            this.GridRef.filter(this.filterSelectItems[col.field + '_defaults'], col.field, 'in');
            hasToFilter = true;
          }
        });
      }
    }
    if (hasToFilter == false) {
      if (this.GridRef) {
        this.GridRef._filter();
      }
    }
    this.cdr.detectChanges();
  }
  ngAfterViewInit() {
    if (this.isLazyLoad) {
      let incr:number=1;
      this.inetrnalService.gridLazyDataLoad.subscribe((lazyValue: any) => {
        incr++;
        if (lazyValue != null && incr>2) {
           //console.log("incr",incr);
          this.gridData = lazyValue.result;
          this.originalGridData = this.gridData;
          this.totalRecords = lazyValue.totalCount == 0 ? lazyValue.result.length : lazyValue.totalCount;
          this.isLoading = false;
          //this.lazyCount=0;
          // if (IsNotFirstLoad)
          //   this.isLoading = false;

          // if (IsNotFirstLoad == false) {
          //   this.gridData = [];
          //   IsNotFirstLoad = true;
          // }
        }
        else {
          this.isLoading = false;
        }

      });
    }
  }
  
  ngOnDestroy() {
    // if (this.isLazyLoad) {
    // this.inetrnalService.gridLazyDataLoad.unsubscribe();
    // }
  }
  onLazyLoad(event) {
    let targetLazyLoad = new CommonLazyLoad();
    let DataList = [];
    this.gridData = [];
    //this.gridData = [];
    //this.totalRecords=0;
    this.isLoading = true;
    var regEx = /^\d{4}-\d{2}-\d{2}$/;
    Object.getOwnPropertyNames(event.filters).forEach(function (item) {
      var isdate = event.filters[item].value.match(regEx) != null;
      if (isdate)
        DataList.push({ field: item, value: DateFns.format(event.filters[item].value, 'MM/DD/YYYY') });
      else
        DataList.push({ field: item, value: event.filters[item].value });
    });
    targetLazyLoad.filterModels = DataList;
    targetLazyLoad.pageStart = event.first;
    targetLazyLoad.pageSize = event.rows;
    targetLazyLoad.sortField = event.sortField == undefined ? "" : event.sortField;
    targetLazyLoad.sortOrder = event.sortOrder;
    targetLazyLoad.pageName = this.Name;
    this.inetrnalService.gridLazyLoadChange(targetLazyLoad);
  }

  onSelectDropdownChange(event: MouseEvent, rowIndex: number, selectedRowData: T) {
    //console.log("Dropdown change Row Data",selectedRowData)
      this.HandleDropDownChange(event, selectedRowData);
  }
  private HandleDropDownChange(event: any, selectedRowData: T) {
    // if (this.prevTarget) {
    //   this.prevTarget.classList.remove('selectedRow');
    //   this.prevTargetRowData['__selected'] = false;
    // }
    // event.currentTarget.classList.add('selectedRow');
    // selectedRowData['__selected'] = true;
    // this.prevTarget = event.currentTarget;
    // this.prevTargetRowData = selectedRowData;
    // // refresh selected results Count
    // // this.SelectedResultsCount = this.selectedRowsData.length;
    this.DropdownChangeEvent.emit(selectedRowData);
  }

  //Textbox Keypress event 
  textBoxKeyPressEvent(event: Event, rowIndex: number, selectedRowData: T)
  {
    //console.log("KeyPress Event",selectedRowData)
    this.HandleKeyPressEvent(event, rowIndex, selectedRowData);
  }
  private HandleKeyPressEvent(event: any, rowIndex, selectedRowData:T ) {
  var rowInd = { 'rowIndex': rowIndex};
  var merged = Object.assign(event,selectedRowData,rowInd);
   this.KeyPressEvent.emit(merged);
   // this.KeyPressEvent.emit({event:event,selectedRow:selectedRowData});
  }

  //Textbox Keydown event
  textBoxKeyUpEvent(event:Event, rowIndex: number, selectedRowData: T,fieldName:string){
    var rowInd = { 'rowIndex': rowIndex};
    var field = { 'fieldName': fieldName};
    var merged = Object.assign(event,selectedRowData,rowInd,field);
    this.KeyUpEvent.emit(merged);
  }

  //Link icon click event
  LinkIconClick(event: Event, rowIndex: number, selectedRowData: T, field: string)
  {
    var rowInd = { 'rowIndex': rowIndex, 'columnHeader': field};
    var merged = Object.assign(event,selectedRowData,rowInd);
    this.LinkIconClickEvent.emit(merged);
  }
// Added by pxt73120
  getQuarterValue(dateval) {
    if(dateval)
    {
    dateval= dateval|| new Date();
    var m = new Date(dateval).getMonth();
    if(m>2 && m<=5)
      m=4;
    else if(m>5 && m<=8)
      m=7;
    else if(m>8 && m<=11)
     m=9;
    else
      m = Math.floor(new Date(dateval).getMonth() / 3) + 1;
    return new Date(dateval).getFullYear().toString()+"-"+("0" + m.toString())+"-"+"01";
    }
    return dateval;
  }

  showTdDetailsFn(event, rowIndex){
    let rowInd = { 'rowIndex': rowIndex};
    let data = Object.assign(event, rowInd);
    this.showTdDetailsEvent.emit(rowIndex);
  }

  /**
   * DEcimal type keydown event method 
   * @param event 
   * @param data 
   * @param index 
   * @param field 
   */
  decimalcheckKeyDownEvent(event, data, index, field){
    let val = event.srcElement.value;
     if(isNaN(val)){
       val = val.replace(/[^0-9\.]/g,'');
       if(val.split('.').length>2) 
           val =val.replace(/\.+$/,"");
           data[field] = val;
     }
 
     this.textBoxKeyDownEvent(event, index, data,field);
   }

   //Textbox Keydown event
textBoxKeyDownEvent(event:Event, rowIndex: number, selectedRowData: T,fieldName:string){
  var rowInd = { 'rowIndex': rowIndex};
  var field = { 'fieldName': fieldName};
  var merged = Object.assign(event,selectedRowData,rowInd,field);
  this.KeyDownEvent.emit(merged);
}
 
}